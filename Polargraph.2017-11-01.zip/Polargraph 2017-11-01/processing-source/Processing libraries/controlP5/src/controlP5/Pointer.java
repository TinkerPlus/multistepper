package controlP5;

public interface Pointer {

	public int x();
	
	public int y();
	
	public int px();
	
	public int py();
	
	public int dx();
	
	public int dy();
	
	public long pt();
	
	public long dt();
	
	public long t();
}
